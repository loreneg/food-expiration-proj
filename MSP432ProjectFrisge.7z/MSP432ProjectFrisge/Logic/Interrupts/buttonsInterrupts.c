#include "interrupts.h"
#include <ti/grlib/button.h>

#define LCD_WIDTH 128
#define LCD_HEIGHT 128

int8_t menuUnlocked = 0;        //The menu is set to be locked
int8_t notOnMenuScreen = 0;        //The mode has still to be selected

void PORT4_IRQHandler(void)
{
    /* Check which pins generated the interrupts */
    uint_fast16_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P4);
    /* clear interrupt flag (to clear pending interrupt indicator */
    GPIO_clearInterruptFlag(GPIO_PORT_P4, status);

    /* check if we received P3.5 interrupt */
    if((status & GPIO_PIN1)){
        //user has chosen modality
        if(menuUnlocked && notOnMenuScreen){
            notOnMenuScreen = 0;
            drawMenu();
            drawSelection(8000);
        }
    }
}

//Interrupt handler for button S2 on boosterPack
void PORT3_IRQHandler(void)
{
    /* Check which pins generated the interrupts */
    uint_fast16_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P3);
    /* clear interrupt flag (to clear pending interrupt indicator */

    GPIO_clearInterruptFlag(GPIO_PORT_P3, status);
    Graphics_Button yesButton;
    yesButton.xMin = 80;
    yesButton.xMax = 150;
    yesButton.yMin = 80;
    yesButton.yMax = 120;
    yesButton.borderWidth = 1;
    yesButton.selected = true;
    yesButton.fillColor = GRAPHICS_COLOR_RED;
    yesButton.borderColor = GRAPHICS_COLOR_RED;
    yesButton.selectedColor = GRAPHICS_COLOR_BLACK;
    yesButton.textColor = GRAPHICS_COLOR_BLACK;
    yesButton.selectedTextColor = GRAPHICS_COLOR_RED;
    yesButton.textXPos = 100;
    yesButton.textYPos = 90;
    yesButton.text = "YES";
    yesButton.font = &g_sFontCm18;

    /* check if we received P3.5 interrupt */
    if((status & GPIO_PIN5)){

        if(menuUnlocked && !notOnMenuScreen){
            switch(currSelection){
            case FOODLIST:
                Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "FOODLIST", AUTO_STRING_LENGTH, LCD_WIDTH / 2, LCD_HEIGHT / 2, TRANSPARENT_TEXT);
                Graphics_drawButton(&g_sContext, &yesButton);
                break;
            case ADDFOOD:
                Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "ADDFOOD", AUTO_STRING_LENGTH, LCD_WIDTH / 2, LCD_HEIGHT / 2, TRANSPARENT_TEXT);
                break;
            }

            notOnMenuScreen = 1;
        }

        menuUnlocked = 1;   //The menu gets unlocked
    }
}


//Button S1 on BoosterPack Module
void PORT5_IRQHandler(void)
{
    /* Check which pins generated the interrupts */
    uint_fast16_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P5);
    /* clear interrupt flag (to clear pending interrupt indicator */
    GPIO_clearInterruptFlag(GPIO_PORT_P5, status);

    /* check if we received P5.1 interrupt */
    if((status & GPIO_PIN1)){
        menuUnlocked = 1;   //The menu gets unlocked
    }
}

