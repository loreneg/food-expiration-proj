#ifndef __LOGIC_H__
#define __LOGIC_H__

#include <stdint.h>

void _hwInit();

void start_graphics();
void start_menu();
void activate_peripherals();
void drawSelection(uint64_t y);

#endif
