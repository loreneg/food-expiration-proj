#ifndef __MENUGRAPHICS_H__
#define __MENUGRAPHICS_H__
typedef enum {FOODLIST, ADDFOOD} Selection_t;

void startupImage();

void drawMenu();

void drawSelectionAddFood();

void drawSelectionFoodList();



#endif
