#ifndef __GRAPHICS_CONTEXT_H__
#define __GRAPHICS_CONTEXT_H__

#include <ti/grlib/grlib.h>

Graphics_Context g_sContext;

#endif
